package Snapshot;

$VERSION = '0.01';

1;

__END__

=head1 NAME

Snapshot - Snapshot of your installation at Wed Jan  2 17:46:24 2008

=head1 SYNOPSIS

perl -MCPANPLUS -e "install Snapshot"

=head1 CONTENTS

Foo::Bar 0.01
